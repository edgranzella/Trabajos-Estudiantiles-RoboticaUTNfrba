clear all;
close all;
clc;

%==================== Cargar archivo o generarlo ===================
[fName,fPath] = uigetfile('*.dat','Seleccionar archivo de datos para el ploteo');
if fName == 0
    h = helpdlg('No se seleccion� archivo. El script generar� los puntos y har� el ploteo','Aviso');
    uiwait(h);
else
    dat = importdata(strcat(fPath,fName),',');
    dat = dat .*(100/32768);
    figure, plot3(dat(:,1),dat(:,2),dat(:,3),'r');
    figure, scatter3(dat(:,1),dat(:,2),dat(:,3),'.r');
    return;
end

% Constantes del robot
h1 = 80;
h4 = 5;

% GDL del robot
syms q1 d2 d3 q4;

%========================= Variables ===============================
coorRef = [0 0 0 1]';
uint8 i;
q1Min = 0;
q1Max = 1.5*pi;
d2Min = 10;
d2Max = 50;
d3Min = 15;
d3Max = 75;
nDiv = 10;

% Calculo el número de puntos
outSize = 0;
for d2v=d2Min : (d2Max-d2Min)/nDiv : d2Max    
    for d3v=d3Min : (d3Max-d3Min)/nDiv : d3Max
        for q1v=q1Min : (q1Max-q1Min)/nDiv : q1Max
            outSize = outSize + 1;
        end
    end
end
% Creo la matriz para todas las posiciones
out = zeros(4,outSize);
%===================================================================

%=================== Generacion de las matrices ====================
% Parametros: theta, d, a, alpha
A01 = gen_matDH(q1, h1, 0, pi/2);
A12 = gen_matDH(0, d2, 0, pi/2);
A23 = gen_matDH(0, d3, 0, 0);
A34 = gen_matDH(q4, h4, 0, 0);

% Matriz de transformacion completa
T = ((A01*A12)*A23)*A34;
%===================================================================

%================= Calculo del espacio de trabajo ==================
% q4 no se utiliza porque s�lo representa el giro del extremo del robot
i = 1;
q4v = 0;
wb = waitbar(0,'Procesando... (0%)','CreateCancelBtn','setappdata(gcbf,''exit'', 1);');
setappdata(wb,'exit', 0);
for d2v=d2Min : (d2Max-d2Min)/nDiv : d2Max    
    for d3v=d3Min : (d3Max-d3Min)/nDiv : d3Max
        for q1v=q1Min : (q1Max-q1Min)/nDiv : q1Max
            if getappdata(wb,'exit')
                delete(wb);
                return
            end
            out(:,i) = subs(subs(subs(subs(T,q1,q1v),d2,d2v),d3,d3v),q4,q4v)*coorRef;            
            i = i + 1;
            waitbar(i/outSize,wb,sprintf('Procesando... %d/%d (%d%%)',i,outSize,uint8(i/outSize*100)));
        end
    end    
end
delete(wb);
%===================================================================

%============================ Ploteo ===============================
figure, plot3(out(1,:),out(2,:),out(3,:),'r');
figure, scatter3(out(1,:),out(2,:),out(3,:),'.r');

%===================================================================