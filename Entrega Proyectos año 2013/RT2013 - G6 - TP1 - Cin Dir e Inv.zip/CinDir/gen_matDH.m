% Funcion para generar la matriz de transformación homogénea DH
function MTH = gen_matDH(theta_i,d_i,a_i,alpha_i)

% Para la matriz DH genérica
syms sTheta sD sA sAlpha;

sTheta=theta_i;
sD=d_i;
sA=a_i;
sAlpha=alpha_i;

% Matriz de transformación homogénea DH
MTH = [cos(sTheta)   -sin(sTheta)*cos(sAlpha)   -sin(sTheta)*sin(sAlpha)   sA*cos(sTheta);
       sin(sTheta)    cos(sTheta)*cos(sAlpha)   -cos(sTheta)*sin(sAlpha)   sA*sin(sTheta);
       0              sin(sAlpha)                cos(sAlpha)               sD            ;
       0               0                            0                      1             ];

end