clear all;
close all;
clc;

h1 = 80;
h4 = 5;

syms q1 d2 d3 q4;

q1=0;
d2=20;
d3=10;
q4=0;

%          Alpha    A   Theta     D     R=0, P=1
l1 = link([pi/2     0   q1        h1     0]);
l2 = link([pi/2     0   0         d2     1]);
l3 = link([0        0   0         d3     1]);
l4 = link([0        0   q4        h4     0]);

RT2013_TP1 = robot({l1 l2 l3 l4}, 'RT2013_TP1');


drivebot(RT2013_TP1);