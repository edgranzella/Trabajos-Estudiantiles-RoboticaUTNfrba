#ifndef __APPCONFIG_H
#define __APPCONFIG_H

#define  INCLUDE_BSP          /* BSP support - includes SIM, COP, PLL, and INTC */
#define  INCLUDE_DSPFUNC      /* DSP Function library */
#define  INCLUDE_MEMORY        /* Memory support */


#endif
