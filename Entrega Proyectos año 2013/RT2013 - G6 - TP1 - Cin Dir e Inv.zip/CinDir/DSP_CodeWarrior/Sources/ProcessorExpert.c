/** ###################################################################
**     Filename    : ProcessorExpert.c
**     Project     : ProcessorExpert
**     Processor   : 56F8367
**     Version     : Driver 01.14
**     Compiler    : Metrowerks DSP C Compiler
**     Date/Time   : 2013-05-05, 18:36, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/* MODULE ProcessorExpert */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Cpu.h"
#include "Events.h"
#include "MFR1.h"
#include "TFR1.h"
#include "MEM1.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
#include "stdio.h"

#define OUT_FILE "TP1_data.dat"
#define NORM 100
#define Q1_MIN  FRAC16(-(float)0.75) 		//-3/4*PI
#define Q1_MAX  FRAC16((float)0.75)  		//3/4*PI
#define Q1_STEP FRAC16((float)0.15) 	//(1.5*PI)/10
#define D2_MIN  FRAC16((float)10/NORM)
#define D2_MAX  FRAC16((float)50/NORM)
#define D2_STEP FRAC16((float)4/NORM) //(50-10)/10
#define D3_MIN  FRAC16((float)15/NORM)
#define D3_MAX  FRAC16((float)75/NORM)
#define D3_STEP FRAC16((float)6/NORM) //(75-15)/10
void main(void)
{
	Frac16 q1,d2,d3;
	Frac16 L1 = D3_MAX;
	Frac16 x,y,z;
	FILE *out;
			
	PE_low_level_init();
	
	if((out = fopen(OUT_FILE,"wb"))==NULL)
	{
		printf("Error abriendo archivo %s\n",OUT_FILE);
		exit(-1);
	}
	
	for(d2=D2_MIN;d2<D2_MAX;d2=add(d2,D2_STEP))
	{	
		for(d3=D3_MIN;d3<D3_MAX;d3=add(d3,D3_STEP))
		{
			for(q1=Q1_MIN;q1<Q1_MAX;q1=add(q1,Q1_STEP))
			{				
				x = mult(FRAC16(-1),mult(d2,tfr16SinPIx(q1))); 	//x = -d2*sin(q1)				
				y = mult(FRAC16(-1),mult(d2,tfr16CosPIx(q1))); 	//y = -d2*cos(q1)
				z = sub(L1,d3);			  			  			//z = 75-d3
				fprintf(out,"%d,%d,%d\n",x,y,z);
			}
		}
	}
	
  fclose(out);
}

/* END ProcessorExpert */
/*
** ###################################################################
**
**     This file was created by Processor Expert 5.3 [05.01]
**     for the Freescale 56800 series of microcontrollers.
**
** ###################################################################
*/
