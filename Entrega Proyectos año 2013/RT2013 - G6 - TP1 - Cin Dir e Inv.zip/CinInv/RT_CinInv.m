clear all;
close all;
clc;

% Variables para trayectoria
step = 10;
t = zeros(3,step)';
q1t = zeros(1,step);
d2t = zeros(1,step);
d3t = zeros(1,step);

% Constantes del robot
h1 = 80;
h4 = 5;

% Limites del espacio de trabajo
q1Min = -0.75*pi;
q1Max = 0.75*pi;
d2Min = 10;
d2Max = 50;
d3Min = 15;
d3Max = 75;

% Extremo del robot
syms x y z;

% Cinematica Inversa
q1 = asin(-x/(sqrt(x^2+y^2)));
d2 = sqrt(x^2+y^2);
d3 = (h1-h4) - z;

% Ingreso de datos : Verificar que pertenece al espacio de trabajo
pI = input('Ingrese Punto inicial ([x,y,z]): ');
while (subs(subs(q1,x,pI(1)),y,pI(2)) < q1Min || subs(subs(q1,x,pI(1)),y,pI(2)) > q1Max ...
    || subs(subs(d2,x,pI(1)),y,pI(2)) < d2Min || subs(subs(d2,x,pI(1)),y,pI(2)) > d2Max ...
    || subs(d3,z,pI(3)) < d3Min               || subs(d3,z,pI(3)) > d3Max)
    fprintf('El punto no pertenece al espacio de trabajo [q1,d2,d3] = [%f,%f,%f]\n',...
        (180/pi)*subs(subs(q1,x,pI(1)),y,pI(2)),subs(subs(d2,x,pI(1)),y,pI(2)),subs(d3,z,pI(3)));
    pI = input('Ingrese Punto inicial ([x,y,z]): ');
end

pF = input('Ingrese Punto final ([x,y,z]): ');  
while (subs(subs(q1,x,pF(1)),y,pF(2)) < q1Min || subs(subs(q1,x,pF(1)),y,pF(2)) > q1Max ...
    || subs(subs(d2,x,pF(1)),y,pF(2)) < d2Min || subs(subs(d2,x,pF(1)),y,pF(2)) > d2Max ...
    || subs(d3,z,pF(3)) < d3Min               || subs(d3,z,pF(3)) > d3Max)
    fprintf('El punto no pertenece al espacio de trabajo [q1,d2,d3] = [%f,%f,%f]\n',...
        (180/pi)*subs(subs(q1,x,pF(1)),y,pF(2)),subs(subs(d2,x,pF(1)),y,pF(2)),subs(d3,z,pF(3)));
    pF = input('Ingrese Punto final ([x,y,z]): ');
end

% Armo la trayectoria del extremo
t(1,:) = pI;
for i=2:9
    t(i,:) = t(i-1,:) + (pF-pI)/10;
end
t(10,:) = pF;

% Calculo los valores de cada articulacion
for i=1:10
    q1t(i) = subs(subs(q1,x,t(i,1)),y,t(i,2));
    d2t(i) = subs(subs(d2,x,t(i,1)),y,t(i,2));
    d3t(i) = subs(d3,z,t(i,3));
end

% Ploteo trayectoria
subplot(2,2,1);scatter3(t(:,1),t(:,2),t(:,3),'.r');title('Tray. Extremo');

% Ploteo articulaciones
subplot(2,2,2);plot(1:10,180/pi*q1t);title('q1');axis([1 10 q1Min*180/pi q1Max*180/pi]);
subplot(2,2,3);plot(1:10,d2t);title('d2');axis([1 10 d2Min d2Max]);
subplot(2,2,4);plot(1:10,d3t);title('d3');axis([1 10 d3Min d3Max]);