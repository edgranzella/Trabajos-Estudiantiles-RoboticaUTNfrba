// $ANTLR 3.4 /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g 2013-08-19 19:07:18

import java.util.ArrayList;
import java.lang.Math;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked"})
public class PosCilParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "COMMA", "DIGIT", "DOT", "END", "EXP", "HOME", "LOOP", "MIN", "MOV", "MOVS", "NUM", "PLU", "SIGN", "SLEEP", "TIME", "VEL", "WHITESPACE"
    };

    public static final int EOF=-1;
    public static final int COMMA=4;
    public static final int DIGIT=5;
    public static final int DOT=6;
    public static final int END=7;
    public static final int EXP=8;
    public static final int HOME=9;
    public static final int LOOP=10;
    public static final int MIN=11;
    public static final int MOV=12;
    public static final int MOVS=13;
    public static final int NUM=14;
    public static final int PLU=15;
    public static final int SIGN=16;
    public static final int SLEEP=17;
    public static final int TIME=18;
    public static final int VEL=19;
    public static final int WHITESPACE=20;

    // delegates
    public Parser[] getDelegates() {
        return new Parser[] {};
    }

    // delegators


    public PosCilParser(TokenStream input) {
        this(input, new RecognizerSharedState());
    }
    public PosCilParser(TokenStream input, RecognizerSharedState state) {
        super(input, state);
    }

    public String[] getTokenNames() { return PosCilParser.tokenNames; }
    public String getGrammarFileName() { return "/home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g"; }

    		
    	static final double h1 = 800E-3;
    	static final double h4 = 50E-3;

    	static final double q1Min = -0.75*Math.PI;
    	static final double q1Max = 0.75*Math.PI;
    	static final double d2Min = 100E-3;
    	static final double d2Max = 500E-3;
    	static final double d3Min = 150E-3;
    	static final double d3Max = 750E-3;
    	
    	static final double homeX = 100E-3;
    	static final double homeY = 100E-3;
    	static final double homeZ = 0;
    	static final double homeOr= 0;
    	
    	static final int step = 20;

    	static double pI[] = new double[]{homeX,homeY,homeZ,homeOr};
    	static double pF[] = new double[]{homeX,homeY,homeZ,homeOr};
    	static final double home[] = new double[]{homeX,homeY,homeZ,homeOr};
    		
    	static ArrayList<double[]> tray = null;
    		
    	public static void main(String[] args) throws Exception {
    		PosCilLexer lex = new PosCilLexer(new ANTLRFileStream(args[0]));
    		CommonTokenStream tokens = new CommonTokenStream(lex);
    		PosCilParser parser = new PosCilParser(tokens);
    		try {
    			parser.expr();
    		}catch (RecognitionException e){
    			e.printStackTrace();
    		}
    	}
    	
    	private static void genTray(IntStream input, String rule) throws RecognitionException{
    		tray = new ArrayList();
    		double delta[] = vDiffAndScale(pF,pI,(double)1/step);
    		double pAux[] = pI;
    		tray.add(pI);
    		for(int i=1; i<step-1; i++){
    			pAux = vAdd(pAux,delta);
    			tray.add(pAux);
    		}
    		tray.add(pF);
    		for(double[] p : tray){
    			if(!validate(p))
    				throw new FailedPredicateException(input,rule + ". El punto de la trayectoria [" + 
    				p[0] + "," + p[1] + "," + p[2] + "] no pertence al espacio de trabajo. ", vToStr(pF));
    		}
    	}
    			
    	private static double[] vDiffAndScale(double[] v1,double[] v2, double s){
    		if(v1 == null || v2 == null || v1.length != v2.length || s == 0)
    			return null;
    		double[] res = new double[v1.length];
    		for(int i=0; i<v1.length; i++)
    			res[i] = s*(v1[i] - v2[i]);
    		return res;
    	}
    	
    	private static double[] vAdd(double[] v1,double[] v2){
    		if(v1 == null || v2 == null || v1.length != v2.length)
    			return null;
    		double[] res = new double[v1.length];
    		for(int i=0; i<v1.length; i++)
    			res[i] = v1[i] + v2[i];
    		return res;
    	}
        
    	private static boolean validate (double p[]) {
    		if(p == null || (p.length != 3 && p.length != 4))
    			return false;
    		double[] art = cinInv(p);
    		double q1 = art[0];
    		double d2 = art[1];
    		double d3 = art[2];
    		return (q1<=q1Max && q1>=q1Min && d2<=d2Max && d2>=d2Min && d3<=d3Max && d3>=d3Min);
    	}
    	
    	private static double[] cinInv (double p[]) {
    		if(p == null || (p.length != 3 && p.length != 4))
    			return null;	
    		double x = p[0];
    		double y = p[1];
    		double z = p[2];
    		double q1 = Math.asin(-x/(Math.sqrt(Math.pow(x,2)+Math.pow(y,2))));
    		double d2 = Math.sqrt(Math.pow(x,2)+Math.pow(y,2));	
    		double d3 = (h1-h4) - z;
    		if(p.length == 3)
    			return new double[]{q1,d2,d3};
    		else
    			return new double[]{q1,d2,d3,p[3]};
    	}
    	
    	
    	private static double[] cinDir (double a[]) {
    		if(a == null || (a.length != 3 && a.length != 4))
    			return null;	
    		double q1 = a[0];
    		double d2 = a[1];
    		double d3 = a[2];		
    		double x = -d2*Math.sin(q1);
    		double y = d2*Math.cos(q1);
    		double z = (h1-h4)-d3;		
    		if(a.length == 3)
    			return new double[]{x,y,z};
    		else
    			return new double[]{x,y,z,a[3]};
    	}
    	
    	private static String vToStr(double[] p){
    		return (p == null || p.length != 4 ? "" : p[0] + "," + p[1] + "," + p[2] + "," + p[3]);
    	}
    	
    	private boolean vEquals(double[] v1, double[] v2){
    		if(v1 == null || v2 == null || v1.length != v2.length || v1.length != 4)
    			return false;
    		return (v1[0] == v2[0] && v1[1] == v2[1] && v1[2] == v2[2] && v1[3] == v2[3]);
    	}
    	
    	private static double vel2Time(double[] v1, double[] v2,double vel){
    		if(v1 == null || v2 == null || v1.length != v2.length || v1.length != 4 || vel == 0)
    			return -1;
    		double dis = Math.sqrt(Math.pow(v1[0]-v2[0],2) + Math.pow(v1[1]-v2[1],2) + Math.pow(v1[2]-v2[2],2));
    		if(dis < 0.01)
    			return 1;
    		else
    			return dis / vel;
    	}



    // $ANTLR start "expr"
    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:159:1: expr : ( loop | home | movSimple | movTime | movVel | movSmooth | sleep )+ ;
    public final void expr() throws RecognitionException {
        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:159:7: ( ( loop | home | movSimple | movTime | movVel | movSmooth | sleep )+ )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:159:9: ( loop | home | movSimple | movTime | movVel | movSmooth | sleep )+
            {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:159:9: ( loop | home | movSimple | movTime | movVel | movSmooth | sleep )+
            int cnt1=0;
            loop1:
            do {
                int alt1=8;
                switch ( input.LA(1) ) {
                case LOOP:
                    {
                    alt1=1;
                    }
                    break;
                case HOME:
                    {
                    alt1=2;
                    }
                    break;
                case MOV:
                    {
                    int LA1_4 = input.LA(2);

                    if ( (LA1_4==NUM) ) {
                        int LA1_7 = input.LA(3);

                        if ( (LA1_7==COMMA) ) {
                            int LA1_8 = input.LA(4);

                            if ( (LA1_8==NUM) ) {
                                int LA1_9 = input.LA(5);

                                if ( (LA1_9==COMMA) ) {
                                    int LA1_10 = input.LA(6);

                                    if ( (LA1_10==NUM) ) {
                                        switch ( input.LA(7) ) {
                                        case END:
                                        case HOME:
                                        case LOOP:
                                        case MOV:
                                        case MOVS:
                                        case SLEEP:
                                            {
                                            alt1=3;
                                            }
                                            break;
                                        case COMMA:
                                            {
                                            int LA1_13 = input.LA(8);

                                            if ( (LA1_13==NUM) ) {
                                                switch ( input.LA(9) ) {
                                                case END:
                                                case HOME:
                                                case LOOP:
                                                case MOV:
                                                case MOVS:
                                                case SLEEP:
                                                    {
                                                    alt1=3;
                                                    }
                                                    break;
                                                case TIME:
                                                    {
                                                    alt1=4;
                                                    }
                                                    break;
                                                case VEL:
                                                    {
                                                    alt1=5;
                                                    }
                                                    break;

                                                }

                                            }


                                            }
                                            break;
                                        case TIME:
                                            {
                                            alt1=4;
                                            }
                                            break;
                                        case VEL:
                                            {
                                            alt1=5;
                                            }
                                            break;

                                        }

                                    }


                                }


                            }


                        }


                    }


                    }
                    break;
                case MOVS:
                    {
                    alt1=6;
                    }
                    break;
                case SLEEP:
                    {
                    alt1=7;
                    }
                    break;

                }

                switch (alt1) {
            	case 1 :
            	    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:159:10: loop
            	    {
            	    pushFollow(FOLLOW_loop_in_expr168);
            	    loop();

            	    state._fsp--;


            	    }
            	    break;
            	case 2 :
            	    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:159:17: home
            	    {
            	    pushFollow(FOLLOW_home_in_expr172);
            	    home();

            	    state._fsp--;


            	    }
            	    break;
            	case 3 :
            	    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:159:24: movSimple
            	    {
            	    pushFollow(FOLLOW_movSimple_in_expr176);
            	    movSimple();

            	    state._fsp--;


            	    }
            	    break;
            	case 4 :
            	    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:159:36: movTime
            	    {
            	    pushFollow(FOLLOW_movTime_in_expr180);
            	    movTime();

            	    state._fsp--;


            	    }
            	    break;
            	case 5 :
            	    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:159:46: movVel
            	    {
            	    pushFollow(FOLLOW_movVel_in_expr184);
            	    movVel();

            	    state._fsp--;


            	    }
            	    break;
            	case 6 :
            	    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:159:55: movSmooth
            	    {
            	    pushFollow(FOLLOW_movSmooth_in_expr188);
            	    movSmooth();

            	    state._fsp--;


            	    }
            	    break;
            	case 7 :
            	    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:159:67: sleep
            	    {
            	    pushFollow(FOLLOW_sleep_in_expr192);
            	    sleep();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return ;
    }
    // $ANTLR end "expr"



    // $ANTLR start "loop"
    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:161:1: loop : LOOP n= integ ( expr ) END ;
    public final void loop() throws RecognitionException {
        int n =0;


        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:161:6: ( LOOP n= integ ( expr ) END )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:161:8: LOOP n= integ ( expr ) END
            {
            match(input,LOOP,FOLLOW_LOOP_in_loop202); 

            pushFollow(FOLLOW_integ_in_loop206);
            n=integ();

            state._fsp--;



            		System.out.println("for i=1:" + n);
                   

            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:164:8: ( expr )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:164:9: expr
            {
            pushFollow(FOLLOW_expr_in_loop218);
            expr();

            state._fsp--;


            }


            match(input,END,FOLLOW_END_in_loop228); 


            		System.out.println("end");
                   

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return ;
    }
    // $ANTLR end "loop"



    // $ANTLR start "home"
    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:169:1: home : HOME ;
    public final void home() throws RecognitionException {
        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:169:6: ( HOME )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:169:8: HOME
            {
            match(input,HOME,FOLLOW_HOME_in_home238); 


            		if(this.vEquals(pI,home)){
            			System.out.println("% ALREADY AT HOME, command ignored");
            		}else{
            			pF = home;
            			System.out.println("gen_MovSmooth([" + this.vToStr(pI) + "],[" + this.vToStr(pF) + "],10);");
            			pI = pF;
            		}
            	    

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return ;
    }
    // $ANTLR end "home"



    // $ANTLR start "movSimple"
    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:179:1: movSimple : ( MOV x= coor COMMA y= coor COMMA z= coor | MOV x= coor COMMA y= coor COMMA z= coor COMMA or= ang );
    public final void movSimple() throws RecognitionException {
        PosCilParser.coor_return x =null;

        PosCilParser.coor_return y =null;

        PosCilParser.coor_return z =null;

        double or =0.0;


        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:179:11: ( MOV x= coor COMMA y= coor COMMA z= coor | MOV x= coor COMMA y= coor COMMA z= coor COMMA or= ang )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==MOV) ) {
                int LA2_1 = input.LA(2);

                if ( (LA2_1==NUM) ) {
                    int LA2_2 = input.LA(3);

                    if ( (LA2_2==COMMA) ) {
                        int LA2_3 = input.LA(4);

                        if ( (LA2_3==NUM) ) {
                            int LA2_4 = input.LA(5);

                            if ( (LA2_4==COMMA) ) {
                                int LA2_5 = input.LA(6);

                                if ( (LA2_5==NUM) ) {
                                    int LA2_6 = input.LA(7);

                                    if ( (LA2_6==END||(LA2_6 >= HOME && LA2_6 <= LOOP)||(LA2_6 >= MOV && LA2_6 <= MOVS)||LA2_6==SLEEP) ) {
                                        alt2=1;
                                    }
                                    else if ( (LA2_6==COMMA) ) {
                                        alt2=2;
                                    }
                                    else {
                                        NoViableAltException nvae =
                                            new NoViableAltException("", 2, 6, input);

                                        throw nvae;

                                    }
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 2, 5, input);

                                    throw nvae;

                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 2, 4, input);

                                throw nvae;

                            }
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 2, 3, input);

                            throw nvae;

                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 2, 2, input);

                        throw nvae;

                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 2, 1, input);

                    throw nvae;

                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;

            }
            switch (alt2) {
                case 1 :
                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:179:13: MOV x= coor COMMA y= coor COMMA z= coor
                    {
                    match(input,MOV,FOLLOW_MOV_in_movSimple248); 

                    pushFollow(FOLLOW_coor_in_movSimple252);
                    x=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movSimple254); 

                    pushFollow(FOLLOW_coor_in_movSimple258);
                    y=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movSimple260); 

                    pushFollow(FOLLOW_coor_in_movSimple264);
                    z=coor();

                    state._fsp--;



                    		String c = "[" + (x!=null?input.toString(x.start,x.stop):null) + "," + (y!=null?input.toString(y.start,y.stop):null) + "," + (z!=null?input.toString(z.start,z.stop):null) + "]";
                    		if(this.validate(new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0)})){
                    			pF = new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0),pI[3]};
                    		}else{
                    			throw new FailedPredicateException(input,"movSimple. El punto [" + c + "] no pertence al espacio de trabajo. ",c);
                    		}
                    		this.genTray(input,"movSimple");		
                    		System.out.println("gen_Mov([" + this.vToStr(pI) + "],[" + this.vToStr(pF) + "],30," + this.step + ");");
                    		pI = pF;
                                

                    }
                    break;
                case 2 :
                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:190:13: MOV x= coor COMMA y= coor COMMA z= coor COMMA or= ang
                    {
                    match(input,MOV,FOLLOW_MOV_in_movSimple280); 

                    pushFollow(FOLLOW_coor_in_movSimple284);
                    x=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movSimple286); 

                    pushFollow(FOLLOW_coor_in_movSimple290);
                    y=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movSimple292); 

                    pushFollow(FOLLOW_coor_in_movSimple296);
                    z=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movSimple298); 

                    pushFollow(FOLLOW_ang_in_movSimple302);
                    or=ang();

                    state._fsp--;



                           		String c = "[" + (x!=null?input.toString(x.start,x.stop):null) + "," + (y!=null?input.toString(y.start,y.stop):null) + "," + (z!=null?input.toString(z.start,z.stop):null) + "]";
                    		if(this.validate(new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0)})){
                    			pF = new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0),or};
                    		}else{
                    			throw new FailedPredicateException(input,"movSimple. El punto [" + c + "] no pertence al espacio de trabajo. ",c);
                    		}
                    		this.genTray(input,"movSimple");		
                    		System.out.println("gen_Mov([" + this.vToStr(pI) + "],[" + this.vToStr(pF) + "],30," + this.step + ");");
                    		pI = pF;
                                

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return ;
    }
    // $ANTLR end "movSimple"



    // $ANTLR start "movTime"
    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:202:1: movTime : ( MOV x= coor COMMA y= coor COMMA z= coor TIME t= NUM | MOV x= coor COMMA y= coor COMMA z= coor COMMA or= ang TIME t= NUM );
    public final void movTime() throws RecognitionException {
        Token t=null;
        PosCilParser.coor_return x =null;

        PosCilParser.coor_return y =null;

        PosCilParser.coor_return z =null;

        double or =0.0;


        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:202:9: ( MOV x= coor COMMA y= coor COMMA z= coor TIME t= NUM | MOV x= coor COMMA y= coor COMMA z= coor COMMA or= ang TIME t= NUM )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==MOV) ) {
                int LA3_1 = input.LA(2);

                if ( (LA3_1==NUM) ) {
                    int LA3_2 = input.LA(3);

                    if ( (LA3_2==COMMA) ) {
                        int LA3_3 = input.LA(4);

                        if ( (LA3_3==NUM) ) {
                            int LA3_4 = input.LA(5);

                            if ( (LA3_4==COMMA) ) {
                                int LA3_5 = input.LA(6);

                                if ( (LA3_5==NUM) ) {
                                    int LA3_6 = input.LA(7);

                                    if ( (LA3_6==TIME) ) {
                                        alt3=1;
                                    }
                                    else if ( (LA3_6==COMMA) ) {
                                        alt3=2;
                                    }
                                    else {
                                        NoViableAltException nvae =
                                            new NoViableAltException("", 3, 6, input);

                                        throw nvae;

                                    }
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 3, 5, input);

                                    throw nvae;

                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 3, 4, input);

                                throw nvae;

                            }
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 3, 3, input);

                            throw nvae;

                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 2, input);

                        throw nvae;

                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 1, input);

                    throw nvae;

                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;

            }
            switch (alt3) {
                case 1 :
                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:202:11: MOV x= coor COMMA y= coor COMMA z= coor TIME t= NUM
                    {
                    match(input,MOV,FOLLOW_MOV_in_movTime312); 

                    pushFollow(FOLLOW_coor_in_movTime317);
                    x=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movTime319); 

                    pushFollow(FOLLOW_coor_in_movTime323);
                    y=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movTime325); 

                    pushFollow(FOLLOW_coor_in_movTime329);
                    z=coor();

                    state._fsp--;


                    match(input,TIME,FOLLOW_TIME_in_movTime331); 

                    t=(Token)match(input,NUM,FOLLOW_NUM_in_movTime335); 


                    		String c = "[" + (x!=null?input.toString(x.start,x.stop):null) + "," + (y!=null?input.toString(y.start,y.stop):null) + "," + (z!=null?input.toString(z.start,z.stop):null) + "]";
                    		if(this.validate(new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0)})){
                    			pF = new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0),pI[3]};
                    		}else{
                    			throw new FailedPredicateException(input,"movTime. El punto [" + c + "] no pertence al espacio de trabajo. ",c);
                    		}
                    		this.genTray(input,"movTime");		
                    		System.out.println("gen_Mov([" + this.vToStr(pI) + "],[" + this.vToStr(pF) + "]," + (t!=null?t.getText():null) + "," + this.step + ");");
                    		pI = pF;
                    	  

                    }
                    break;
                case 2 :
                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:213:4: MOV x= coor COMMA y= coor COMMA z= coor COMMA or= ang TIME t= NUM
                    {
                    match(input,MOV,FOLLOW_MOV_in_movTime342); 

                    pushFollow(FOLLOW_coor_in_movTime346);
                    x=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movTime348); 

                    pushFollow(FOLLOW_coor_in_movTime352);
                    y=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movTime354); 

                    pushFollow(FOLLOW_coor_in_movTime358);
                    z=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movTime360); 

                    pushFollow(FOLLOW_ang_in_movTime364);
                    or=ang();

                    state._fsp--;


                    match(input,TIME,FOLLOW_TIME_in_movTime366); 

                    t=(Token)match(input,NUM,FOLLOW_NUM_in_movTime370); 


                            	String c = "[" + (x!=null?input.toString(x.start,x.stop):null) + "," + (y!=null?input.toString(y.start,y.stop):null) + "," + (z!=null?input.toString(z.start,z.stop):null) + "]";
                    		if(this.validate(new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0)})){
                    			pF = new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0),or};
                    		}else{
                    			throw new FailedPredicateException(input,"movTime. El punto [" + c + "] no pertence al espacio de trabajo. ",c);
                    		}
                    		this.genTray(input,"movTime");		
                    		System.out.println("gen_Mov([" + this.vToStr(pI) + "],[" + this.vToStr(pF) + "]," + (t!=null?t.getText():null) + "," + this.step + ");");
                    		pI = pF;
                              

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return ;
    }
    // $ANTLR end "movTime"



    // $ANTLR start "movVel"
    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:225:1: movVel : ( MOV x= coor COMMA y= coor COMMA z= coor VEL v= NUM | MOV x= coor COMMA y= coor COMMA z= coor COMMA or= ang VEL v= NUM );
    public final void movVel() throws RecognitionException {
        Token v=null;
        PosCilParser.coor_return x =null;

        PosCilParser.coor_return y =null;

        PosCilParser.coor_return z =null;

        double or =0.0;


        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:225:8: ( MOV x= coor COMMA y= coor COMMA z= coor VEL v= NUM | MOV x= coor COMMA y= coor COMMA z= coor COMMA or= ang VEL v= NUM )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==MOV) ) {
                int LA4_1 = input.LA(2);

                if ( (LA4_1==NUM) ) {
                    int LA4_2 = input.LA(3);

                    if ( (LA4_2==COMMA) ) {
                        int LA4_3 = input.LA(4);

                        if ( (LA4_3==NUM) ) {
                            int LA4_4 = input.LA(5);

                            if ( (LA4_4==COMMA) ) {
                                int LA4_5 = input.LA(6);

                                if ( (LA4_5==NUM) ) {
                                    int LA4_6 = input.LA(7);

                                    if ( (LA4_6==VEL) ) {
                                        alt4=1;
                                    }
                                    else if ( (LA4_6==COMMA) ) {
                                        alt4=2;
                                    }
                                    else {
                                        NoViableAltException nvae =
                                            new NoViableAltException("", 4, 6, input);

                                        throw nvae;

                                    }
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 4, 5, input);

                                    throw nvae;

                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 4, 4, input);

                                throw nvae;

                            }
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 4, 3, input);

                            throw nvae;

                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 2, input);

                        throw nvae;

                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 1, input);

                    throw nvae;

                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;

            }
            switch (alt4) {
                case 1 :
                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:225:10: MOV x= coor COMMA y= coor COMMA z= coor VEL v= NUM
                    {
                    match(input,MOV,FOLLOW_MOV_in_movVel385); 

                    pushFollow(FOLLOW_coor_in_movVel390);
                    x=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movVel392); 

                    pushFollow(FOLLOW_coor_in_movVel396);
                    y=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movVel398); 

                    pushFollow(FOLLOW_coor_in_movVel402);
                    z=coor();

                    state._fsp--;


                    match(input,VEL,FOLLOW_VEL_in_movVel404); 

                    v=(Token)match(input,NUM,FOLLOW_NUM_in_movVel408); 


                    		String c = "[" + (x!=null?input.toString(x.start,x.stop):null) + "," + (y!=null?input.toString(y.start,y.stop):null) + "," + (z!=null?input.toString(z.start,z.stop):null) + "]";			
                    		if(this.validate(new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0)})){
                    			pF = new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0),pI[3]};
                    		}else{
                    			throw new FailedPredicateException(input,"movVel. El punto [" + c + "] no pertence al espacio de trabajo. ",c);
                    		}
                    		double time = vel2Time(pI,pF,Double.parseDouble((v!=null?v.getText():null)));
                    		if(time < 1)
                    			throw new FailedPredicateException(input,"movVel. La velocidad seleccioada es muy elevada",c);
                    		this.genTray(input,"movVel");
                    		System.out.println("gen_Mov([" + this.vToStr(pI) + "],[" + this.vToStr(pF) + "]," + time + "," + this.step + ");");
                    		pI = pF;
                    	 

                    }
                    break;
                case 2 :
                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:239:10: MOV x= coor COMMA y= coor COMMA z= coor COMMA or= ang VEL v= NUM
                    {
                    match(input,MOV,FOLLOW_MOV_in_movVel421); 

                    pushFollow(FOLLOW_coor_in_movVel426);
                    x=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movVel428); 

                    pushFollow(FOLLOW_coor_in_movVel432);
                    y=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movVel434); 

                    pushFollow(FOLLOW_coor_in_movVel438);
                    z=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movVel440); 

                    pushFollow(FOLLOW_ang_in_movVel444);
                    or=ang();

                    state._fsp--;


                    match(input,VEL,FOLLOW_VEL_in_movVel446); 

                    v=(Token)match(input,NUM,FOLLOW_NUM_in_movVel450); 


                           		String c = "[" + (x!=null?input.toString(x.start,x.stop):null) + "," + (y!=null?input.toString(y.start,y.stop):null) + "," + (z!=null?input.toString(z.start,z.stop):null) + "]";
                    		if(this.validate(new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0)})){
                    			pF = new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0),or};
                    		}else{
                    			throw new FailedPredicateException(input,"movVel. El punto [" + c + "] no pertence al espacio de trabajo. ",c);
                    		}
                    		double time = vel2Time(pI,pF,Double.parseDouble((v!=null?v.getText():null)));
                    		if(time < 1)
                    			throw new FailedPredicateException(input,"movVel. La velocidad seleccioada es muy elevada",c);
                    		this.genTray(input,"movVel");
                    		System.out.println("gen_Mov([" + this.vToStr(pI) + "],[" + this.vToStr(pF) + "]," + time + "," + this.step + ");");
                    		pI = pF;
                           	 

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return ;
    }
    // $ANTLR end "movVel"



    // $ANTLR start "movSmooth"
    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:254:1: movSmooth : ( MOVS x= coor COMMA y= coor COMMA z= coor | MOVS x= coor COMMA y= coor COMMA z= coor COMMA or= ang );
    public final void movSmooth() throws RecognitionException {
        PosCilParser.coor_return x =null;

        PosCilParser.coor_return y =null;

        PosCilParser.coor_return z =null;

        double or =0.0;


        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:254:11: ( MOVS x= coor COMMA y= coor COMMA z= coor | MOVS x= coor COMMA y= coor COMMA z= coor COMMA or= ang )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==MOVS) ) {
                int LA5_1 = input.LA(2);

                if ( (LA5_1==NUM) ) {
                    int LA5_2 = input.LA(3);

                    if ( (LA5_2==COMMA) ) {
                        int LA5_3 = input.LA(4);

                        if ( (LA5_3==NUM) ) {
                            int LA5_4 = input.LA(5);

                            if ( (LA5_4==COMMA) ) {
                                int LA5_5 = input.LA(6);

                                if ( (LA5_5==NUM) ) {
                                    int LA5_6 = input.LA(7);

                                    if ( (LA5_6==END||(LA5_6 >= HOME && LA5_6 <= LOOP)||(LA5_6 >= MOV && LA5_6 <= MOVS)||LA5_6==SLEEP) ) {
                                        alt5=1;
                                    }
                                    else if ( (LA5_6==COMMA) ) {
                                        alt5=2;
                                    }
                                    else {
                                        NoViableAltException nvae =
                                            new NoViableAltException("", 5, 6, input);

                                        throw nvae;

                                    }
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 5, 5, input);

                                    throw nvae;

                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 5, 4, input);

                                throw nvae;

                            }
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 5, 3, input);

                            throw nvae;

                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 5, 2, input);

                        throw nvae;

                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 5, 1, input);

                    throw nvae;

                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;

            }
            switch (alt5) {
                case 1 :
                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:254:13: MOVS x= coor COMMA y= coor COMMA z= coor
                    {
                    match(input,MOVS,FOLLOW_MOVS_in_movSmooth460); 

                    pushFollow(FOLLOW_coor_in_movSmooth464);
                    x=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movSmooth466); 

                    pushFollow(FOLLOW_coor_in_movSmooth470);
                    y=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movSmooth472); 

                    pushFollow(FOLLOW_coor_in_movSmooth476);
                    z=coor();

                    state._fsp--;



                    		String c = "[" + (x!=null?input.toString(x.start,x.stop):null) + "," + (y!=null?input.toString(y.start,y.stop):null) + "," + (z!=null?input.toString(z.start,z.stop):null) + "]";			
                    		if(this.validate(new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0)})){
                    			pF = new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0),pI[3]};
                    		}else{
                    			throw new FailedPredicateException(input,"movSmooth. El punto [" + c + "] no pertence al espacio de trabajo. ",c);
                    		}				
                    		System.out.println("gen_MovSmooth([" + this.vToStr(pI) + "],[" + this.vToStr(pF) + "],10);");
                    		pI = pF;
                    	

                    }
                    break;
                case 2 :
                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:263:6: MOVS x= coor COMMA y= coor COMMA z= coor COMMA or= ang
                    {
                    match(input,MOVS,FOLLOW_MOVS_in_movSmooth482); 

                    pushFollow(FOLLOW_coor_in_movSmooth486);
                    x=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movSmooth488); 

                    pushFollow(FOLLOW_coor_in_movSmooth492);
                    y=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movSmooth494); 

                    pushFollow(FOLLOW_coor_in_movSmooth498);
                    z=coor();

                    state._fsp--;


                    match(input,COMMA,FOLLOW_COMMA_in_movSmooth500); 

                    pushFollow(FOLLOW_ang_in_movSmooth504);
                    or=ang();

                    state._fsp--;



                    	       	String c = "[" + (x!=null?input.toString(x.start,x.stop):null) + "," + (y!=null?input.toString(y.start,y.stop):null) + "," + (z!=null?input.toString(z.start,z.stop):null) + "]";
                    		if(this.validate(new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0)})){
                    			pF = new double[]{(x!=null?x.value:0.0),(y!=null?y.value:0.0),(z!=null?z.value:0.0),or};
                    		}else{
                    			throw new FailedPredicateException(input,"movSmooth. El punto [" + c + "] no pertence al espacio de trabajo. ",c);
                    		}
                    		System.out.println("gen_MovSmooth([" + this.vToStr(pI) + "],[" + this.vToStr(pF) + "],10);");
                    		pI = pF;
                    	

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return ;
    }
    // $ANTLR end "movSmooth"



    // $ANTLR start "sleep"
    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:274:1: sleep : SLEEP t= NUM ;
    public final void sleep() throws RecognitionException {
        Token t=null;

        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:274:7: ( SLEEP t= NUM )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:274:9: SLEEP t= NUM
            {
            match(input,SLEEP,FOLLOW_SLEEP_in_sleep514); 

            t=(Token)match(input,NUM,FOLLOW_NUM_in_sleep518); 


            		System.out.println("sleep(" + (t!=null?t.getText():null) + ");");
            	    

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return ;
    }
    // $ANTLR end "sleep"


    public static class coor_return extends ParserRuleReturnScope {
        public double value;
    };


    // $ANTLR start "coor"
    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:278:1: coor returns [double value] : NUM ;
    public final PosCilParser.coor_return coor() throws RecognitionException {
        PosCilParser.coor_return retval = new PosCilParser.coor_return();
        retval.start = input.LT(1);


        Token NUM1=null;

        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:279:7: ( NUM )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:279:9: NUM
            {
            NUM1=(Token)match(input,NUM,FOLLOW_NUM_in_coor539); 

            retval.value = Double.parseDouble((NUM1!=null?NUM1.getText():null));

            }

            retval.stop = input.LT(-1);


        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "coor"



    // $ANTLR start "ang"
    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:281:1: ang returns [double value] : NUM ;
    public final double ang() throws RecognitionException {
        double value = 0.0;


        Token NUM2=null;

        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:282:7: ( NUM )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:282:9: NUM
            {
            NUM2=(Token)match(input,NUM,FOLLOW_NUM_in_ang566); 

            value = Math.toRadians(Double.parseDouble((NUM2!=null?NUM2.getText():null))%360);

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return value;
    }
    // $ANTLR end "ang"



    // $ANTLR start "integ"
    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:284:1: integ returns [int value] : NUM ;
    public final int integ() throws RecognitionException {
        int value = 0;


        Token NUM3=null;

        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:285:7: ( NUM )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:285:9: NUM
            {
            NUM3=(Token)match(input,NUM,FOLLOW_NUM_in_integ587); 

            value = Integer.parseInt((NUM3!=null?NUM3.getText():null));

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return value;
    }
    // $ANTLR end "integ"

    // Delegated rules


 

    public static final BitSet FOLLOW_loop_in_expr168 = new BitSet(new long[]{0x0000000000023602L});
    public static final BitSet FOLLOW_home_in_expr172 = new BitSet(new long[]{0x0000000000023602L});
    public static final BitSet FOLLOW_movSimple_in_expr176 = new BitSet(new long[]{0x0000000000023602L});
    public static final BitSet FOLLOW_movTime_in_expr180 = new BitSet(new long[]{0x0000000000023602L});
    public static final BitSet FOLLOW_movVel_in_expr184 = new BitSet(new long[]{0x0000000000023602L});
    public static final BitSet FOLLOW_movSmooth_in_expr188 = new BitSet(new long[]{0x0000000000023602L});
    public static final BitSet FOLLOW_sleep_in_expr192 = new BitSet(new long[]{0x0000000000023602L});
    public static final BitSet FOLLOW_LOOP_in_loop202 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_integ_in_loop206 = new BitSet(new long[]{0x0000000000023600L});
    public static final BitSet FOLLOW_expr_in_loop218 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_END_in_loop228 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_HOME_in_home238 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_MOV_in_movSimple248 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movSimple252 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movSimple254 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movSimple258 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movSimple260 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movSimple264 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_MOV_in_movSimple280 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movSimple284 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movSimple286 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movSimple290 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movSimple292 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movSimple296 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movSimple298 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_ang_in_movSimple302 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_MOV_in_movTime312 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movTime317 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movTime319 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movTime323 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movTime325 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movTime329 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_TIME_in_movTime331 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_NUM_in_movTime335 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_MOV_in_movTime342 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movTime346 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movTime348 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movTime352 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movTime354 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movTime358 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movTime360 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_ang_in_movTime364 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_TIME_in_movTime366 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_NUM_in_movTime370 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_MOV_in_movVel385 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movVel390 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movVel392 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movVel396 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movVel398 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movVel402 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_VEL_in_movVel404 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_NUM_in_movVel408 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_MOV_in_movVel421 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movVel426 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movVel428 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movVel432 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movVel434 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movVel438 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movVel440 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_ang_in_movVel444 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_VEL_in_movVel446 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_NUM_in_movVel450 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_MOVS_in_movSmooth460 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movSmooth464 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movSmooth466 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movSmooth470 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movSmooth472 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movSmooth476 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_MOVS_in_movSmooth482 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movSmooth486 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movSmooth488 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movSmooth492 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movSmooth494 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_coor_in_movSmooth498 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_COMMA_in_movSmooth500 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_ang_in_movSmooth504 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SLEEP_in_sleep514 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_NUM_in_sleep518 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUM_in_coor539 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUM_in_ang566 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUM_in_integ587 = new BitSet(new long[]{0x0000000000000002L});

}