// $ANTLR 3.4 /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g 2013-08-19 19:07:19

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked"})
public class PosCilLexer extends Lexer {
    public static final int EOF=-1;
    public static final int COMMA=4;
    public static final int DIGIT=5;
    public static final int DOT=6;
    public static final int END=7;
    public static final int EXP=8;
    public static final int HOME=9;
    public static final int LOOP=10;
    public static final int MIN=11;
    public static final int MOV=12;
    public static final int MOVS=13;
    public static final int NUM=14;
    public static final int PLU=15;
    public static final int SIGN=16;
    public static final int SLEEP=17;
    public static final int TIME=18;
    public static final int VEL=19;
    public static final int WHITESPACE=20;

    // delegates
    // delegators
    public Lexer[] getDelegates() {
        return new Lexer[] {};
    }

    public PosCilLexer() {} 
    public PosCilLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public PosCilLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);
    }
    public String getGrammarFileName() { return "/home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g"; }

    // $ANTLR start "COMMA"
    public final void mCOMMA() throws RecognitionException {
        try {
            int _type = COMMA;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:2:7: ( ',' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:2:9: ','
            {
            match(','); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "COMMA"

    // $ANTLR start "DOT"
    public final void mDOT() throws RecognitionException {
        try {
            int _type = DOT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:3:5: ( '.' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:3:7: '.'
            {
            match('.'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "DOT"

    // $ANTLR start "END"
    public final void mEND() throws RecognitionException {
        try {
            int _type = END;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:4:5: ( 'END' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:4:7: 'END'
            {
            match("END"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "END"

    // $ANTLR start "EXP"
    public final void mEXP() throws RecognitionException {
        try {
            int _type = EXP;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:5:5: ( 'E' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:5:7: 'E'
            {
            match('E'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "EXP"

    // $ANTLR start "HOME"
    public final void mHOME() throws RecognitionException {
        try {
            int _type = HOME;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:6:6: ( 'HOME' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:6:8: 'HOME'
            {
            match("HOME"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "HOME"

    // $ANTLR start "LOOP"
    public final void mLOOP() throws RecognitionException {
        try {
            int _type = LOOP;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:7:6: ( 'LOOP' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:7:8: 'LOOP'
            {
            match("LOOP"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "LOOP"

    // $ANTLR start "MIN"
    public final void mMIN() throws RecognitionException {
        try {
            int _type = MIN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:8:5: ( '-' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:8:7: '-'
            {
            match('-'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "MIN"

    // $ANTLR start "MOV"
    public final void mMOV() throws RecognitionException {
        try {
            int _type = MOV;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:9:5: ( 'MOV' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:9:7: 'MOV'
            {
            match("MOV"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "MOV"

    // $ANTLR start "MOVS"
    public final void mMOVS() throws RecognitionException {
        try {
            int _type = MOVS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:10:6: ( 'MOVS' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:10:8: 'MOVS'
            {
            match("MOVS"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "MOVS"

    // $ANTLR start "PLU"
    public final void mPLU() throws RecognitionException {
        try {
            int _type = PLU;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:11:5: ( '+' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:11:7: '+'
            {
            match('+'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "PLU"

    // $ANTLR start "SLEEP"
    public final void mSLEEP() throws RecognitionException {
        try {
            int _type = SLEEP;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:12:7: ( 'SLEEP' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:12:9: 'SLEEP'
            {
            match("SLEEP"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "SLEEP"

    // $ANTLR start "TIME"
    public final void mTIME() throws RecognitionException {
        try {
            int _type = TIME;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:13:6: ( 'ti' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:13:8: 'ti'
            {
            match("ti"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "TIME"

    // $ANTLR start "VEL"
    public final void mVEL() throws RecognitionException {
        try {
            int _type = VEL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:14:5: ( 've' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:14:7: 've'
            {
            match("ve"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "VEL"

    // $ANTLR start "NUM"
    public final void mNUM() throws RecognitionException {
        try {
            int _type = NUM;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:290:5: ( ( SIGN )? ( DIGIT )+ ( DOT ( DIGIT )+ )? ( EXP SIGN ( DIGIT )+ )? )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:290:7: ( SIGN )? ( DIGIT )+ ( DOT ( DIGIT )+ )? ( EXP SIGN ( DIGIT )+ )?
            {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:290:7: ( SIGN )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0=='+'||LA1_0=='-') ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:
                    {
                    if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                        input.consume();
                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;
                    }


                    }
                    break;

            }


            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:290:15: ( DIGIT )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0 >= '0' && LA2_0 <= '9')) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:
            	    {
            	    if ( (input.LA(1) >= '0' && input.LA(1) <= '9') ) {
            	        input.consume();
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:290:24: ( DOT ( DIGIT )+ )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0=='.') ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:290:25: DOT ( DIGIT )+
                    {
                    mDOT(); 


                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:290:29: ( DIGIT )+
                    int cnt3=0;
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( ((LA3_0 >= '0' && LA3_0 <= '9')) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:
                    	    {
                    	    if ( (input.LA(1) >= '0' && input.LA(1) <= '9') ) {
                    	        input.consume();
                    	    }
                    	    else {
                    	        MismatchedSetException mse = new MismatchedSetException(null,input);
                    	        recover(mse);
                    	        throw mse;
                    	    }


                    	    }
                    	    break;

                    	default :
                    	    if ( cnt3 >= 1 ) break loop3;
                                EarlyExitException eee =
                                    new EarlyExitException(3, input);
                                throw eee;
                        }
                        cnt3++;
                    } while (true);


                    }
                    break;

            }


            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:290:40: ( EXP SIGN ( DIGIT )+ )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0=='E') ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:290:41: EXP SIGN ( DIGIT )+
                    {
                    mEXP(); 


                    mSIGN(); 


                    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:290:50: ( DIGIT )+
                    int cnt5=0;
                    loop5:
                    do {
                        int alt5=2;
                        int LA5_0 = input.LA(1);

                        if ( ((LA5_0 >= '0' && LA5_0 <= '9')) ) {
                            alt5=1;
                        }


                        switch (alt5) {
                    	case 1 :
                    	    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:
                    	    {
                    	    if ( (input.LA(1) >= '0' && input.LA(1) <= '9') ) {
                    	        input.consume();
                    	    }
                    	    else {
                    	        MismatchedSetException mse = new MismatchedSetException(null,input);
                    	        recover(mse);
                    	        throw mse;
                    	    }


                    	    }
                    	    break;

                    	default :
                    	    if ( cnt5 >= 1 ) break loop5;
                                EarlyExitException eee =
                                    new EarlyExitException(5, input);
                                throw eee;
                        }
                        cnt5++;
                    } while (true);


                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "NUM"

    // $ANTLR start "WHITESPACE"
    public final void mWHITESPACE() throws RecognitionException {
        try {
            int _type = WHITESPACE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:291:12: ( ( '\\t' | ' ' | '\\r' | '\\n' | '\\u000C' )+ )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:291:14: ( '\\t' | ' ' | '\\r' | '\\n' | '\\u000C' )+
            {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:291:14: ( '\\t' | ' ' | '\\r' | '\\n' | '\\u000C' )+
            int cnt7=0;
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( ((LA7_0 >= '\t' && LA7_0 <= '\n')||(LA7_0 >= '\f' && LA7_0 <= '\r')||LA7_0==' ') ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:
            	    {
            	    if ( (input.LA(1) >= '\t' && input.LA(1) <= '\n')||(input.LA(1) >= '\f' && input.LA(1) <= '\r')||input.LA(1)==' ' ) {
            	        input.consume();
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt7 >= 1 ) break loop7;
                        EarlyExitException eee =
                            new EarlyExitException(7, input);
                        throw eee;
                }
                cnt7++;
            } while (true);


             _channel = HIDDEN; 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "WHITESPACE"

    // $ANTLR start "DIGIT"
    public final void mDIGIT() throws RecognitionException {
        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:292:16: ( '0' .. '9' )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:
            {
            if ( (input.LA(1) >= '0' && input.LA(1) <= '9') ) {
                input.consume();
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;
            }


            }


        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "DIGIT"

    // $ANTLR start "SIGN"
    public final void mSIGN() throws RecognitionException {
        try {
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:293:15: ( ( MIN | PLU ) )
            // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:
            {
            if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                input.consume();
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;
            }


            }


        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "SIGN"

    public void mTokens() throws RecognitionException {
        // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:8: ( COMMA | DOT | END | EXP | HOME | LOOP | MIN | MOV | MOVS | PLU | SLEEP | TIME | VEL | NUM | WHITESPACE )
        int alt8=15;
        switch ( input.LA(1) ) {
        case ',':
            {
            alt8=1;
            }
            break;
        case '.':
            {
            alt8=2;
            }
            break;
        case 'E':
            {
            int LA8_3 = input.LA(2);

            if ( (LA8_3=='N') ) {
                alt8=3;
            }
            else {
                alt8=4;
            }
            }
            break;
        case 'H':
            {
            alt8=5;
            }
            break;
        case 'L':
            {
            alt8=6;
            }
            break;
        case '-':
            {
            int LA8_6 = input.LA(2);

            if ( ((LA8_6 >= '0' && LA8_6 <= '9')) ) {
                alt8=14;
            }
            else {
                alt8=7;
            }
            }
            break;
        case 'M':
            {
            int LA8_7 = input.LA(2);

            if ( (LA8_7=='O') ) {
                int LA8_17 = input.LA(3);

                if ( (LA8_17=='V') ) {
                    int LA8_19 = input.LA(4);

                    if ( (LA8_19=='S') ) {
                        alt8=9;
                    }
                    else {
                        alt8=8;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 8, 17, input);

                    throw nvae;

                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 7, input);

                throw nvae;

            }
            }
            break;
        case '+':
            {
            int LA8_8 = input.LA(2);

            if ( ((LA8_8 >= '0' && LA8_8 <= '9')) ) {
                alt8=14;
            }
            else {
                alt8=10;
            }
            }
            break;
        case 'S':
            {
            alt8=11;
            }
            break;
        case 't':
            {
            alt8=12;
            }
            break;
        case 'v':
            {
            alt8=13;
            }
            break;
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
            {
            alt8=14;
            }
            break;
        case '\t':
        case '\n':
        case '\f':
        case '\r':
        case ' ':
            {
            alt8=15;
            }
            break;
        default:
            NoViableAltException nvae =
                new NoViableAltException("", 8, 0, input);

            throw nvae;

        }

        switch (alt8) {
            case 1 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:10: COMMA
                {
                mCOMMA(); 


                }
                break;
            case 2 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:16: DOT
                {
                mDOT(); 


                }
                break;
            case 3 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:20: END
                {
                mEND(); 


                }
                break;
            case 4 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:24: EXP
                {
                mEXP(); 


                }
                break;
            case 5 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:28: HOME
                {
                mHOME(); 


                }
                break;
            case 6 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:33: LOOP
                {
                mLOOP(); 


                }
                break;
            case 7 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:38: MIN
                {
                mMIN(); 


                }
                break;
            case 8 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:42: MOV
                {
                mMOV(); 


                }
                break;
            case 9 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:46: MOVS
                {
                mMOVS(); 


                }
                break;
            case 10 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:51: PLU
                {
                mPLU(); 


                }
                break;
            case 11 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:55: SLEEP
                {
                mSLEEP(); 


                }
                break;
            case 12 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:61: TIME
                {
                mTIME(); 


                }
                break;
            case 13 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:66: VEL
                {
                mVEL(); 


                }
                break;
            case 14 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:70: NUM
                {
                mNUM(); 


                }
                break;
            case 15 :
                // /home/pablo-1015px/Materias/Robotica/RT2013/ANTLR/PosCil.g:1:74: WHITESPACE
                {
                mWHITESPACE(); 


                }
                break;

        }

    }


 

}