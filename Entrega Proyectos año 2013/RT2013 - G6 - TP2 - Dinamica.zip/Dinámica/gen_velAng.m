% Función para generar la matriz de velocidad angular NE
function wjj = gen_velAng(tipo,rij,wii,qVel)

    % Para la matriz de velocidad angular NE genérica
    syms sRij sWii sQVel;
    z0 = [0,0,1]';

    sRij = rij;
    sWii=wii;
    sQVel=qVel;
    
    % Matriz de velocidad angular NE
    switch tipo 
        case 'rot' % Rotación        
            wjj = vpa(sRij*(sWii + z0*sQVel),6);
        case 'tra' % Traslación
            wjj = vpa(sRij*sWii,6);
        otherwise
            error('Tipo no válido. Use rot(ación) o tra(slación).')
    end

end