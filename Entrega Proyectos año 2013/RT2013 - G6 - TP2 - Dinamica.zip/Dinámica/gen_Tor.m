% Función para generar la matriz de aceleración lineal NE
function tii = gen_Tor(tipo,rij,fii,nii)

    % Para la matriz de aceleración lineal NE genérica
    syms sRij sFii sNii;
    z0 = [0,0,1]';

    sRij = rij;
    sFii = fii;
    sNii = nii;
        
    % Matriz de aceleración lineal NE
    switch tipo 
        case 'rot' % Rotación        
            tii = vpa(sNii'*sRij*z0,6);
        case 'tra' % Traslación
            tii = vpa(sFii'*sRij*z0,6);
        otherwise
            error('Tipo no válido. Use rot(ación) o tra(slación).')
    end

end