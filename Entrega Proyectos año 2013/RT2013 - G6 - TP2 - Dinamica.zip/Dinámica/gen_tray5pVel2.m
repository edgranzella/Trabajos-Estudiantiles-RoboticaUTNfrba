function tray = gen_tray5pVel2(pI,pF,T,steps,vel)

    % Para la generacion de la trayectoria    
    syms t;
    tray = zeros(1,steps+1)';
    tv = 0 : T/steps : T;
        
    % Parámetros para trayectoria
    a0 = pI;
    a1 = vel;
    a2 = 0;
    a3 = (-20*pI+20*pF-12*T*vel)/(2*T^3);
    a4 = (30*pI-30*pF+16*T*vel)/(2*T^4);
    a5 = (-12*pI+12*pF-6*T*vel)/(2*T^5);
    
    % Valores inicial y final
    tray(1,:) = pI;
    tray(steps+1,:) = pF;
    
    % Trayectoria generada
    f = a0 + a1*t + a2*t^2 + a3*t^3 + a4*t^4 + a5*t^5;
    for i=2:steps
        tray(i,:) = subs(f,t,tv(i));
    end
end