clear all;
close all;
clc;
digits(6);

% Constantes del robot
h1 = 800*1e-3;
h4 = 50*1e-3;

% GDL del robot
syms q1 d2 d3 q4;

% Velocidades
syms q1Vel d2Vel d3Vel q4Vel;

% Aceleraciones
syms q1Ace d2Ace d3Ace q4Ace;

% Variables NE
z0 = [0,0,1]';
w00 = [0,0,0]';
pi00 = [0,0,0]';
v00 = [0,0,0]';
a00 = [0,0,-9.81]';
f55 = [0,0,0];

% Coordenadas del origen del sistema {Si} respecto de {Si-1} [ai, diSi, diCi]
p11 = [0,h1*sin(q1),h1*cos(q1)]';
p22 = [0,0,d2]';
p33 = [0,0,d3]';
p44 = [0,h4*sin(q4),h4*cos(q4)]';

% Coordenadas del centro de masa del eslabón i a su sistema {Si}
s11 = [0,770-357.07518042,0]'*1e-3;
s22 = [0,-146.93036793,0]'*1e-3;
s33 = [0,0,342.5]'*1e-3;  
s44 = [0,0,46.46975623]'*1e-3;

% Matriz de inceria del eslabón i respecto a su centro de masa
I11 = [2248184.84866885,0,0; 0,7681.86297256,0; 0,0,2248184.84866885]*1e-6;
I22 = [180150.37879299,0,0; 0,1426.8166668,0; 0,0,179643.37879299]*1e-6;
I33 = [590926.69952495,0,0; 0,590926.69952495,0; 0,0,424.88371669]*1e-6;
I44 = [773.99473893,0,0; 0,773.99473893,0; 0,0,245.88511233]*1e-6;

% Masas de los eslabones
m1 = 9.94840755;
m2 = 3.95837037;
m3 = 3.77674415;
m4 = 0.85120812;


%========================= Variables ===============================
q1Min = 0;
q1Max = 1.5*pi;
d2Min = 100e-3;
d2Max = 500e-3;
d3Min = 150e-3;
d3Max = 750e-3;
%===================================================================

%============ Generación de las matrices de rotación ===============
% Parametros: theta, d, a, alpha
A01 = gen_matDH(q1, h1, 0, pi/2);
r01 = A01(1:3,1:3);
r10 = r01';

A12 = gen_matDH(0, d2, 0, pi/2);
r12 = A12(1:3,1:3);
r21 = r12';

A23 = gen_matDH(0, d3, 0, 0);
r23 = A23(1:3,1:3);
r32 = r23';

A34 = gen_matDH(q4, h4, 0, 0);
r34 = A34(1:3,1:3);
r43 = r34';
%===================================================================

%================= Velocidades angulares de NE =====================
w11 = gen_velAng('rot',r10,w00,q1Vel);
w22 = gen_velAng('tra',r21,w11,d2Vel);
w33 = gen_velAng('tra',r32,w22,d3Vel);
w44 = gen_velAng('rot',r43,w33,q4Vel);
%===================================================================

%================ Aceleraciones angulares de NE ====================
pi11 = gen_aceAng('rot',r10,pi00,w00,q1Vel,q1Ace);
pi22 = gen_aceAng('tra',r21,pi11,w11,d2Vel,d2Ace);
pi33 = gen_aceAng('tra',r32,pi22,w22,d3Vel,d3Ace);
pi44 = gen_aceAng('rot',r43,pi33,w33,q4Vel,q4Ace);
%===================================================================

%================ Aceleraciones lineales de NE =====================
a11 = gen_aceLin('rot',r10,a00,pi11,w11,q1Vel,q1Ace,p11);
a22 = gen_aceLin('tra',r21,a11,pi22,w22,d2Vel,d2Ace,p22);
a33 = gen_aceLin('tra',r32,a22,pi33,w33,d3Vel,d3Ace,p33);
a44 = gen_aceLin('rot',r43,a33,pi44,w44,q4Vel,q4Ace,p44);
%===================================================================

%========== Aceleraciones lineales por centro de gravedad ==========
ac11 = vpa(cross(pi11,s11) + cross(w11,cross(w11,s11)) + a11,6);
ac22 = vpa(cross(pi22,s22) + cross(w22,cross(w22,s22)) + a22,6);
ac33 = vpa(cross(pi33,s33) + cross(w33,cross(w33,s33)) + a33,6);
ac44 = vpa(cross(pi44,s44) + cross(w44,cross(w44,s44)) + a44,6);
%===================================================================

%============== Fuerzas ejercidas sobre cada eslabón ===============
f44 = vpa(m4*ac44,6);
f33 = vpa(r34*f44 + m3*ac33,6);
f22 = vpa(r23*f33 + m2*ac22,6);
f11 = vpa(r12*f22 + m1*ac11,6);
%===================================================================

%=============== Pares ejercidos sobre cada eslabón ================
n44 = vpa(cross(p44+s44,m4*ac44) + I44*pi44 + cross(w44,I44*w44),6);
n33 = vpa(r34*(n44 + cross(r43*p33,f44)) + cross(p33+s33,m3*ac33) + I33*pi33 + cross(w33,I33*w33),6);
n22 = vpa(r23*(n33 + cross(r32*p22,f33)) + cross(p22+s22,m2*ac22) + I22*pi22 + cross(w22,I22*w22),6);
n11 = vpa(r12*(n22 + cross(r21*p11,f22)) + cross(p11+s11,m1*ac11) + I11*pi11 + cross(w11,I11*w11),6);
%===================================================================

%================= Fuerza o torque de cada eslabón =================
T1 = gen_Tor('rot',r10,f11,n11)
F2 = gen_Tor('tra',r21,f22,n22)
F3 = gen_Tor('tra',r32,f33,n33)
T4 = gen_Tor('rot',r43,f44,n44)
%===================================================================
