% Función para generar la matriz de aceleración angular NE
function pjj = gen_aceAng(tipo,rij,pii,wii,qVel,qAce)

    % Para la matriz de aceleración angular NE genérica
    syms sRij sPii sWii sQVel sQAce;
    z0 = [0,0,1]';

    sRij = rij;
    sPii = pii;
    sWii=wii;
    sQVel=qVel;
    sQAce = qAce;
        
    % Matriz de aceleración angular NE
    switch tipo 
        case 'rot' % Rotación        
            pjj = vpa(sRij*(sPii + z0*sQAce) + cross(sWii,z0*sQVel),6);
        case 'tra' % Traslación
            pjj = vpa(sRij*sPii,6);
        otherwise
            error('Tipo no válido. Use rot(ación) o tra(slación).')
    end

end