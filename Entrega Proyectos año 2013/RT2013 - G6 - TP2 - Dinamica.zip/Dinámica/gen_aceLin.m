% Función para generar la matriz de aceleración lineal NE
function ajj = gen_aceLin(tipo,rij,aii,pii,wii,qVel,qAce,ppii)

    % Para la matriz de aceleración lineal NE genérica
    syms sRij sAii sPii sWii sQVel sQAce sPPii;
    z0 = [0,0,1]';

    sRij = rij;
    sAii = aii;
    sPii = pii;
    sWii=wii;
    sQVel=qVel;
    sQAce = qAce;
    sPPii = ppii;
        
    % Matriz de aceleración lineal NE
    switch tipo 
        case 'rot' % Rotación        
            ajj = vpa(cross(sPii,sPPii) + cross(sWii,cross(sWii,sPPii)) + sRij*sAii,6);
        case 'tra' % Traslación
            ajj = vpa(sRij*(z0*sQAce + sAii) + cross(sPii,sPPii) + cross(2*sWii,sRij*(z0*sQVel)) + cross(sWii,cross(sWii,sPPii)),6);
        otherwise
            error('Tipo no válido. Use rot(ación) o tra(slación).')
    end

end