clear all;
close all;
clc;

tipo = input('Ingrese tipo de trayectoria (l=lineal o 5p=polinomial 5 orden): ');
if(tipo ~='l')
    fprintf('Trayectoria polinomica seleccionada\n');
else
    fprintf('Trayectoria lineal seleccionada\n');
end

% Variables para trayectoria
step = 20;
t = zeros(3,step)';
q1t = zeros(1,step);
d2t = zeros(1,step);
d3t = zeros(1,step);

% Constantes del robot
h1 = 800*1e-3;
h4 = 50*1e-3;

% Limites del espacio de trabajo
q1Min = -0.75*pi;
q1Max = 0.75*pi;
d2Min = 100e-3;
d2Max = 500e-3;
d3Min = 150e-3;
d3Max = 750e-3;

%============== Extremo del robot ==============%
% Posiciones
syms x y z;

% Velocidades
syms xv yv zv;

% Aceleraciones
syms xa ya za;

%============== Cinematica Inversa ==============%
% Posiciones
q1 = asin(-x/(sqrt(x^2+y^2)));
d2 = sqrt(x^2+y^2);
d3 = (h1-h4) - z;

% Velocidades
q1v = diff(q1,x)*xv + diff(q1,y)*yv;
d2v = diff(d2,x)*xv + diff(d2,y)*yv;
d3v = diff(d3,z)*zv;

% Ingreso de datos : Verificar que pertenece al espacio de trabajo
pI = input('Ingrese Punto inicial ([x,y,z]): ');
while (subs(subs(q1,x,pI(1)),y,pI(2)) < q1Min || subs(subs(q1,x,pI(1)),y,pI(2)) > q1Max ...
    || subs(subs(d2,x,pI(1)),y,pI(2)) < d2Min || subs(subs(d2,x,pI(1)),y,pI(2)) > d2Max ...
    || subs(d3,z,pI(3)) < d3Min               || subs(d3,z,pI(3)) > d3Max)
    fprintf('El punto no pertenece al espacio de trabajo [q1,d2,d3] = [%f,%f,%f]\n',...
        (180/pi)*subs(subs(q1,x,pI(1)),y,pI(2)),subs(subs(d2,x,pI(1)),y,pI(2)),subs(d3,z,pI(3)));
    pI = input('Ingrese Punto inicial ([x,y,z]): ');
end

pF = input('Ingrese Punto final ([x,y,z]): ');  
while (subs(subs(q1,x,pF(1)),y,pF(2)) < q1Min || subs(subs(q1,x,pF(1)),y,pF(2)) > q1Max ...
    || subs(subs(d2,x,pF(1)),y,pF(2)) < d2Min || subs(subs(d2,x,pF(1)),y,pF(2)) > d2Max ...
    || subs(d3,z,pF(3)) < d3Min               || subs(d3,z,pF(3)) > d3Max)
    fprintf('El punto no pertenece al espacio de trabajo [q1,d2,d3] = [%f,%f,%f]\n',...
        (180/pi)*subs(subs(q1,x,pF(1)),y,pF(2)),subs(subs(d2,x,pF(1)),y,pF(2)),subs(d3,z,pF(3)));
    pF = input('Ingrese Punto final ([x,y,z]): ');
end

T = input('Ingrese Tiempo (seg): ');  
while (T <= 0)
    fprintf('Ingrese un Tiempo mayor a cero\n');
    T = input('Ingrese Tiempo (seg): ');
end

% Proceso según la trayectoria seleccionada
if(tipo ~='l') %Polinomica orden 5    

    % Valores iniciales
    q1t(1) = subs(subs(q1,x,pI(1)),y,pI(2));
    d2t(1) = subs(subs(d2,x,pI(1)),y,pI(2));
    d3t(1) = subs(d3,z,pI(3));
    
    % Valores intermedios
    q1t(step/2) = subs(subs(q1,x,(pF(1)+pI(1))/2),y,(pF(2)+pI(2))/2);
    d2t(step/2) = subs(subs(d2,x,(pF(1)+pI(1))/2),y,(pF(2)+pI(2))/2);
    d3t(step/2) = subs(d3,z,(pF(3)+pI(3))/2);
    
    % Valores finales
    q1t(step) = subs(subs(q1,x,pF(1)),y,pF(2));
    d2t(step) = subs(subs(d2,x,pF(1)),y,pF(2));
    d3t(step) = subs(d3,z,pF(3));
    
    % Velocidades (adopto vel max = 1.5 veces vel promedio)
    xvVal = 1.5*(pF(1)-pI(1))/T;
    yvVal = 1.5*(pF(2)-pI(2))/T;
    zvVal = 1.5*(pF(3)-pI(3))/T;
    
    q1Vel = subs(subs(subs(subs(q1v,xv,xvVal),yv,yvVal),x,(pF(1)+pI(1))/2),y,(pF(2)+pI(2))/2);
    d2Vel = subs(subs(subs(subs(d2v,xv,xvVal),yv,yvVal),x,(pF(1)+pI(1))/2),y,(pF(2)+pI(2))/2);
    d3Vel = subs(subs(d3v,zv,zvVal),z,(pF(3)+pI(3))/2);
    
    % Trayectorias articulares
    q1t(1:step/2) = gen_tray5pVel1(q1t(1),q1t(step/2),T,step/2-1,q1Vel);
    d2t(1:step/2) = gen_tray5pVel1(d2t(1),d2t(step/2),T,step/2-1,d2Vel);
    d3t(1:step/2) = gen_tray5pVel1(d3t(1),d3t(step/2),T,step/2-1,d3Vel);
    
    q1t(step/2:step) = gen_tray5pVel2(q1t(step/2),q1t(step),T,step/2,q1Vel);
    d2t(step/2:step) = gen_tray5pVel2(d2t(step/2),d2t(step),T,step/2,d2Vel);
    d3t(step/2:step) = gen_tray5pVel2(d3t(step/2),d3t(step),T,step/2,d3Vel);
    
    % Trayectoria extremo
    syms q1s d2s d3s;
    xExp = -d2s*sin(q1s);
    yExp = -d2s*cos(q1s);
    zExp = 750e-3 - d3s;
    for i=1:step
        t(i,:) = [subs(subs(xExp,q1s,q1t(i)),d2s,d2t(i)), ...
                  subs(subs(yExp,q1s,q1t(i)),d2s,d2t(i)), ...
                  subs(zExp,d3s,d3t(i))];
    end
    
else % Lineal
    
    % Trayectoria extremo
    t(1,:) = pI;
    for i=2:step-1
        t(i,:) = t(i-1,:) + (pF-pI)/step;
    end
    t(step,:) = pF;

    % Calculo los valores de cada articulacion
    for i=1:step
        q1t(i) = subs(subs(q1,x,t(i,1)),y,t(i,2));
        d2t(i) = subs(subs(d2,x,t(i,1)),y,t(i,2));
        d3t(i) = subs(d3,z,t(i,3));
    end
end

% Ploteo trayectoria
figure,scatter3(t(:,1),t(:,2),t(:,3),'.r');title('Trayectoria Extremo');

% Guardo trayectorias
save('RT_2013_trayectorias.mat','q1t','d2t','d3t');